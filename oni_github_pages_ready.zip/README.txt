Oni's Love Jar — GitHub Pages

To publish:
1. Sign in to GitHub.
2. Create a NEW PUBLIC repository (example: oni-love-jar).
3. Upload index.html from this folder to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch: main, folder: /(root), then Save.
7. Wait for GitHub Pages to publish and copy the public URL shown on the Pages screen.

The recipient does not need a GitHub account to open the published website.
